# lens

These contracts are not designed to be called on-chain. They simplify
fetching on-chain data from off-chain.
